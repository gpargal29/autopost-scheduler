# Implementation Plan: AI-Powered Quote Auto Scheduler

Building a complete, full-stack demo application showcasing MERN stack proficiency, AI integration, background job scheduling with Node Cron, clean modular architecture, and a modern responsive UI using Vite, React, Tailwind CSS, and Axios.

---

## User Review Required

> [!IMPORTANT]
> **Environment Variables Required in Later Steps**:
> In accordance with your instructions, no secret keys or MongoDB URIs will be assumed or hardcoded. During the setup:
> - **MongoDB URI**: Required when configuring database connection in Step 2.
> - **JWT Secret**: Required for authentication token signing in Step 2.
> - **OpenAI API Key**: Required when setting up the AI Quote Generator in Step 3.

---

## Project Structure & Architecture Overview

The project will be housed in `/Users/babitakhanulia/Desktop/autopost` with a clean separation between backend and frontend services.

```
autopost/
├── backend/
│   ├── config/          # Database, OpenAI, & App configurations
│   ├── controllers/     # Express route handlers
│   ├── routes/          # API route declarations
│   ├── models/          # Mongoose schemas
│   ├── services/        # Business logic & external service abstractions (OpenAI, Scheduler)
│   ├── middleware/      # Auth & error handling middlewares
│   ├── jobs/            # Node Cron scheduled tasks
│   ├── utils/           # Helper functions & response formatters
│   ├── .env.example     # Environment template
│   ├── package.json
│   └── server.js        # Express app entry point
└── frontend/
    ├── src/
    │   ├── components/  # Reusable UI components (Navbar, Modals, Cards, Badges)
    │   ├── pages/       # Route-level page components (Dashboard, Generator, Library, etc.)
    │   ├── layouts/     # Layout wrappers (Sidebar/Header main layout)
    │   ├── context/     # React Context providers (AuthContext, QuoteContext, ToastContext)
    │   ├── services/    # Axios API client & endpoint modules
    │   ├── hooks/       # Custom React hooks
    │   ├── utils/       # Date formatters, constants, helpers
    │   ├── App.jsx      # Main app component & routes
    │   ├── index.css    # Tailwind CSS & custom design system tokens
    │   └── main.jsx     # React entry point
    ├── index.html
    ├── package.json
    ├── tailwind.config.js
    └── vite.config.js
```

---

## Phased Feature Roadmap

### Step 1: Initialization & Scaffolding (CURRENT STEP)
- Create backend `package.json` and install core dependencies (`express`, `mongoose`, `cors`, `dotenv`, `jsonwebtoken`, `bcryptjs`, `node-cron`, `openai`).
- Create basic Express server setup with CORS, JSON parsing, error handler middleware, and health check route `/api/health`.
- Initialize standard backend directory structure (`config/`, `controllers/`, `routes/`, `models/`, `services/`, `middleware/`, `jobs/`, `utils/`).
- Initialize React frontend with Vite in `frontend/`.
- Configure Tailwind CSS, custom design tokens, and basic layout container.
- Set up React Router and Axios instance with base API client configuration.

### Step 2: JWT Authentication (NEXT FEATURE)
- Backend: User Schema, Auth Controller (Register, Login, Me), JWT Middleware.
- Frontend: Auth Context, Login Page, Register Page, Protected Route Wrapper.

### Step 3: AI Quote Generator
- Backend: OpenAI Service for structured prompt generation (Quote, Caption, Explanation, Hashtags, Emoji Suggestions, Image Prompt, Posting Time, Engagement Tips), Quote Mongoose Schema, Quote Controller & Routes.
- Frontend: AI Generator Form UI, Category Selector (12 categories), Interactive AI Output Preview, Save/Schedule options.

### Step 4: Quote Library & Smart Scheduler
- Backend: CRUD endpoints for quotes, Search & Filter query logic, Schedule endpoint (Manual & AI recommended time).
- Frontend: Interactive Library Grid/Table, Filtering by category/status, Edit Modal, Duplicate/Delete actions, Schedule Modal.

### Step 5: Background Scheduler (Node Cron)
- Backend: Cron job initialization (`jobs/cronJobs.js`), process pending quotes scheduled for current timestamp, status updater (`Pending` -> `Scheduled` -> `Posted` / `Failed`).
- Frontend: Status updates visualization, real-time indicators.

### Step 6: Connected Social Accounts & Posting History
- Backend: Social Account schema & mock connection service for LinkedIn, Instagram, Facebook. Posting history log collection.
- Frontend: Social accounts integration page, posting log audit table.

### Step 7: Dashboard Analytics, Recent Activity & Settings
- Backend: Analytics aggregate queries (counts by category, status stats, scheduled upcoming posts). User settings persistence.
- Frontend: Dashboard summary cards, statistics charts/visuals, recent activity stream, quick actions, settings tab.

---

## Verification Plan

### Automated / Terminal Checks
1. Backend setup verification: `npm list` check in `backend/` and verifying Express health endpoint `/api/health`.
2. Frontend setup verification: `npm run build` check in `frontend/` to ensure Vite, Tailwind, React Router compile without errors.

### Manual Verification
- Verify backend directory structure matches all requested folders.
- Verify frontend directory structure matches all requested folders.
- Confirm server runs on local port and Vite dev server initializes properly.
